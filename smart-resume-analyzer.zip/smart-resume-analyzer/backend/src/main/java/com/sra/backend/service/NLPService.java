package com.sra.backend.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.SimpleTokenizer;

import java.io.InputStream;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** NLP: lowercase + punctuation strip, tokenize (OpenNLP), POS tag if model available, extract skill-like tokens. */
@Service
public class NLPService {
    private static final Logger log = LogManager.getLogger(NLPService.class);
    private POSTaggerME posTagger;
    private static final Set<String> STOP = new HashSet<>(Arrays.asList("the","a","an","and","or","of","to","in","on","for","with","by","at","as","is","are","be","am","was","were","this","that","these","those","from","your","you","we","our","their","they","it","its","i","me","my"));
    private static final Pattern KEEP = Pattern.compile("^[a-z][a-z0-9+.#\-]{1,39}$");

    public NLPService(){
        try{
            InputStream model = getClass().getResourceAsStream("/models/en-pos-maxent.bin");
            if(model != null){
                posTagger = new POSTaggerME(new POSModel(model));
                log.info("OpenNLP POS model loaded.");
            } else {
                log.warn("POS model not found; using heuristics.");
            }
        }catch(Exception e){
            log.warn("POS model load failed; heuristics in use.", e);
        }
    }

    public String preprocess(String text){
        if(text == null) return "";
        String clean = text.toLowerCase().replaceAll("[^a-z0-9+.#\-\s]", " ");
        return clean.replaceAll("\s+"," ").trim();
    }

    public String[] tokenize(String text){
        return SimpleTokenizer.INSTANCE.tokenize(preprocess(text));
    }

    public List<String> extractKeywords(String text){
        String[] toks = tokenize(text);
        if(toks.length==0) return java.util.Collections.emptyList();
        if(posTagger == null){
            List<String> out = Arrays.stream(toks).filter(t -> !STOP.contains(t) && KEEP.matcher(t).matches()).distinct().collect(Collectors.toList());
            log.info("Heuristic keywords: {}", out.size());
            return out;
        }
        String[] tags = posTagger.tag(toks);
        List<String> out = new ArrayList<>();
        for(int i=0;i<toks.length;i++){
            String t = toks[i]; if(STOP.contains(t)) continue;
            String tag = tags[i];
            if(tag.startsWith("NN") || tag.equals("JJ") || KEEP.matcher(t).matches()) out.add(t);
        }
        List<String> dedup = out.stream().distinct().collect(Collectors.toList());
        log.info("POS keywords: {}", dedup.size());
        return dedup;
    }
}

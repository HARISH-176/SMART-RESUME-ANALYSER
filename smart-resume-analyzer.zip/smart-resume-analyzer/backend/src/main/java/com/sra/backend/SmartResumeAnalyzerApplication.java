package com.sra.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartResumeAnalyzerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartResumeAnalyzerApplication.class, args);
    }
}

package com.sra.backend.service;

import com.openai.Client;
import com.openai.resources.chat.Chat;
import com.openai.types.chat.ChatCompletionCreateParams;

/** Real OpenAI client adapter. Requires OPENAI_API_KEY. */
public class OpenAIClientAdapter implements AIClientAdapter {
    private final String apiKey;
    public OpenAIClientAdapter(String apiKey){ this.apiKey = apiKey; }

    @Override
    public String generateAdvice(String prompt){
        Client client = Client.builder().apiKey(apiKey).build();
        Chat chat = client.chat();
        var params = ChatCompletionCreateParams.builder()
                .model("gpt-4o-mini")
                .messages(java.util.List.of(
                    ChatCompletionCreateParams.Message.builder()
                      .role(ChatCompletionCreateParams.Message.Role.USER)
                      .content(prompt).build()
                ))
                .temperature(0.2).maxTokens(220).build();
        var resp = chat.completions().create(params);
        return resp.getChoices().get(0).getMessage().getContent().get(0).getText();
    }
}
